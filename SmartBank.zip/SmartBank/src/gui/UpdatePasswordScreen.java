/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import gui.settings.IOrganizer;
import gui.settings.textSettings;
import javax.swing.JPasswordField;


public class UpdatePasswordScreen extends javax.swing.JFrame implements IOrganizer{


    public UpdatePasswordScreen() {
        initComponents();
        getEdits();
    }

    @Override
    public void getEdits(){
        this.setLocationRelativeTo(null);
        updatepasswordPanel.setFocusable(true);
        textSettings.setOnlyNumber(azenoTextField);
        textSettings.setMaximumLimit(azenoTextField,8);
        textSettings.setOnlyNumber(phonenoTextField);
        textSettings.setMaximumLimit(phonenoTextField, 10);
    }

    public JPasswordField getpreviousPasswordField(){
        return previousPasswordField;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        updatepasswordPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        updatepasswordPanel = new javax.swing.JPanel();
        previousiconlabel = new javax.swing.JLabel();
        updatepasswordLabel = new javax.swing.JLabel();
        azenoLabel = new javax.swing.JLabel();
        azenoTextField = new javax.swing.JTextField();
        phonenoLabel = new javax.swing.JLabel();
        phonenoTextField = new javax.swing.JTextField();
        securityqueansLabel = new javax.swing.JLabel();
        secqueansTextField = new javax.swing.JTextField();
        previouspassLabel = new javax.swing.JLabel();
        newpassLabel = new javax.swing.JLabel();
        againnewpassLabel = new javax.swing.JLabel();
        newPasswordField = new javax.swing.JPasswordField();
        againnewPasswordField = new javax.swing.JPasswordField();
        previousPasswordField = new javax.swing.JPasswordField();
        updatepasswordButton = new javax.swing.JButton();

        updatepasswordPanel1.setBackground(new java.awt.Color(0, 204, 204));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/imageedit_15_2553631085.png"))); // NOI18N

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 255, 255));
        jLabel7.setText("Update password");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("AZE  No  :");

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Phone  No  :");

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Security question answer:");

        javax.swing.GroupLayout updatepasswordPanel1Layout = new javax.swing.GroupLayout(updatepasswordPanel1);
        updatepasswordPanel1.setLayout(updatepasswordPanel1Layout);
        updatepasswordPanel1Layout.setHorizontalGroup(
            updatepasswordPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, updatepasswordPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(updatepasswordPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addGroup(updatepasswordPanel1Layout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 473, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(updatepasswordPanel1Layout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addGroup(updatepasswordPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(updatepasswordPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(updatepasswordPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(updatepasswordPanel1Layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(102, Short.MAX_VALUE))
        );
        updatepasswordPanel1Layout.setVerticalGroup(
            updatepasswordPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(updatepasswordPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel6)
                .addGap(1, 1, 1)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53)
                .addGroup(updatepasswordPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(updatepasswordPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(updatepasswordPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(165, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        updatepasswordPanel.setBackground(new java.awt.Color(0, 204, 204));

        previousiconlabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/imageedit_15_2553631085.png"))); // NOI18N

        updatepasswordLabel.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        updatepasswordLabel.setForeground(new java.awt.Color(204, 255, 255));
        updatepasswordLabel.setText("Update password");

        azenoLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        azenoLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        azenoLabel.setText("AZE  No  :");

        phonenoLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        phonenoLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        phonenoLabel.setText("Phone  No  :");

        securityqueansLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        securityqueansLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        securityqueansLabel.setText("Security question answer:");

        previouspassLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        previouspassLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        previouspassLabel.setText("Previous password  :");

        newpassLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        newpassLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        newpassLabel.setText("New password  :");

        againnewpassLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        againnewpassLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        againnewpassLabel.setText("Again new password  :");

        updatepasswordButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        updatepasswordButton.setText("Update Password");
        updatepasswordButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatepasswordButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout updatepasswordPanelLayout = new javax.swing.GroupLayout(updatepasswordPanel);
        updatepasswordPanel.setLayout(updatepasswordPanelLayout);
        updatepasswordPanelLayout.setHorizontalGroup(
            updatepasswordPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, updatepasswordPanelLayout.createSequentialGroup()
                .addGroup(updatepasswordPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(updatepasswordPanelLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(previousiconlabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(updatepasswordLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 473, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(updatepasswordPanelLayout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addGroup(updatepasswordPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, updatepasswordPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(updatepasswordPanelLayout.createSequentialGroup()
                                    .addComponent(azenoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(azenoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(updatepasswordPanelLayout.createSequentialGroup()
                                    .addGap(3, 3, 3)
                                    .addComponent(securityqueansLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(secqueansTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(updatepasswordPanelLayout.createSequentialGroup()
                                .addGroup(updatepasswordPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(againnewpassLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(newpassLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(updatepasswordPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(newPasswordField)
                                    .addComponent(againnewPasswordField)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, updatepasswordPanelLayout.createSequentialGroup()
                                .addComponent(previouspassLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(previousPasswordField))
                            .addGroup(updatepasswordPanelLayout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(phonenoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(phonenoTextField)))))
                .addGap(86, 86, 86))
            .addGroup(updatepasswordPanelLayout.createSequentialGroup()
                .addGap(244, 244, 244)
                .addComponent(updatepasswordButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        updatepasswordPanelLayout.setVerticalGroup(
            updatepasswordPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(updatepasswordPanelLayout.createSequentialGroup()
                .addGroup(updatepasswordPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(updatepasswordPanelLayout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(updatepasswordLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(updatepasswordPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(previousiconlabel)))
                .addGap(29, 29, 29)
                .addGroup(updatepasswordPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(azenoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(azenoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(updatepasswordPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(phonenoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(phonenoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(updatepasswordPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(securityqueansLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(secqueansTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(updatepasswordPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(previouspassLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(previousPasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(updatepasswordPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(newpassLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(newPasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(updatepasswordPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(againnewpassLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(againnewPasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(updatepasswordButton, javax.swing.GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
                .addGap(23, 23, 23))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(updatepasswordPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(updatepasswordPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void updatepasswordButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatepasswordButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_updatepasswordButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UpdatePasswordScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UpdatePasswordScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UpdatePasswordScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UpdatePasswordScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UpdatePasswordScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPasswordField againnewPasswordField;
    private javax.swing.JLabel againnewpassLabel;
    private javax.swing.JLabel azenoLabel;
    private javax.swing.JTextField azenoTextField;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JPasswordField newPasswordField;
    private javax.swing.JLabel newpassLabel;
    private javax.swing.JLabel phonenoLabel;
    private javax.swing.JTextField phonenoTextField;
    private javax.swing.JPasswordField previousPasswordField;
    private javax.swing.JLabel previousiconlabel;
    private javax.swing.JLabel previouspassLabel;
    private javax.swing.JTextField secqueansTextField;
    private javax.swing.JLabel securityqueansLabel;
    private javax.swing.JButton updatepasswordButton;
    private javax.swing.JLabel updatepasswordLabel;
    private javax.swing.JPanel updatepasswordPanel;
    private javax.swing.JPanel updatepasswordPanel1;
    // End of variables declaration//GEN-END:variables
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import gui.settings.ActionSettings;
import gui.settings.IOrganizer;
import gui.settings.textSettings;
import javax.swing.JOptionPane;

public class DepositScreen extends javax.swing.JFrame implements IOrganizer {

    private int depositamount=0;

    public DepositScreen() {
        initComponents();
        getEdits();
    }

  @Override
  public void getEdits(){
      this.setLocationRelativeTo(null);
      depositPanel.setFocusable(true);
      textSettings.setOnlyNumber(depositamountTextField);
      textSettings.setMaximumLimit(depositamountTextField, 5);
  }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        depositPanel = new javax.swing.JPanel();
        usernamesurnameLabel = new javax.swing.JLabel();
        limitLabel = new javax.swing.JLabel();
        totalbalanceLabel = new javax.swing.JLabel();
        balanceamountLabel = new javax.swing.JLabel();
        depositamountLabel = new javax.swing.JLabel();
        depositamountTextField = new javax.swing.JTextField();
        depositButton = new javax.swing.JButton();
        previosiconLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        depositPanel.setBackground(new java.awt.Color(153, 255, 153));

        usernamesurnameLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        usernamesurnameLabel.setForeground(new java.awt.Color(255, 0, 51));
        usernamesurnameLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        usernamesurnameLabel.setText("[USERNAME AND SURNAME]");

        limitLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        limitLabel.setText("You can deposit 50000 AZN and less in one go.");

        totalbalanceLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        totalbalanceLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        totalbalanceLabel.setText("Total Balance  :");

        balanceamountLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        balanceamountLabel.setText("[BALANCE]");

        depositamountLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        depositamountLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        depositamountLabel.setText("Amount  :        ");

        depositamountTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                depositamountTextFieldActionPerformed(evt);
            }
        });
        depositamountTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                depositamountTextFieldKeyReleased(evt);
            }
        });

        depositButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        depositButton.setText("Deposit");
        depositButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        depositButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                depositButtonActionPerformed(evt);
            }
        });

        previosiconLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/previousicondeposit.gif"))); // NOI18N
        previosiconLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        previosiconLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                previosiconLabelMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout depositPanelLayout = new javax.swing.GroupLayout(depositPanel);
        depositPanel.setLayout(depositPanelLayout);
        depositPanelLayout.setHorizontalGroup(
            depositPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(depositPanelLayout.createSequentialGroup()
                .addGroup(depositPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(depositPanelLayout.createSequentialGroup()
                        .addGap(84, 84, 84)
                        .addComponent(totalbalanceLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(depositPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(balanceamountLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(depositPanelLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(depositButton))))
                    .addGroup(depositPanelLayout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addGroup(depositPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(limitLabel)
                            .addComponent(usernamesurnameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 535, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(depositPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(previosiconLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(depositPanelLayout.createSequentialGroup()
                        .addGap(88, 88, 88)
                        .addComponent(depositamountLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(depositamountTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        depositPanelLayout.setVerticalGroup(
            depositPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(depositPanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(previosiconLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(usernamesurnameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55)
                .addComponent(limitLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addGroup(depositPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(totalbalanceLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(balanceamountLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(depositPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(depositamountLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(depositamountTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(depositButton, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(depositPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(depositPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void depositamountTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_depositamountTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_depositamountTextFieldActionPerformed

    private void depositamountTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_depositamountTextFieldKeyReleased
        this.depositamount = textSettings.checkTextKeyReleased(depositamountTextField, 50000);
    }//GEN-LAST:event_depositamountTextFieldKeyReleased

    private void depositButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_depositButtonActionPerformed
        JOptionPane.showMessageDialog(this, "Succesfully.\n"+
            "Amount : "+this.depositamount+" AZN.");
        ActionSettings.setVisible(this, new AccountScreen());
    }//GEN-LAST:event_depositButtonActionPerformed

    private void previosiconLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_previosiconLabelMouseClicked
        ActionSettings.setVisible(this, new AccountScreen());
    }//GEN-LAST:event_previosiconLabelMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DepositScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DepositScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DepositScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DepositScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DepositScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel balanceamountLabel;
    private javax.swing.JButton depositButton;
    private javax.swing.JPanel depositPanel;
    private javax.swing.JLabel depositamountLabel;
    private javax.swing.JTextField depositamountTextField;
    private javax.swing.JLabel limitLabel;
    private javax.swing.JLabel previosiconLabel;
    private javax.swing.JLabel totalbalanceLabel;
    private javax.swing.JLabel usernamesurnameLabel;
    // End of variables declaration//GEN-END:variables
}

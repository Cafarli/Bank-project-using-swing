/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import gui.settings.ActionSettings;
import gui.settings.IOrganizer;
import gui.settings.iconsettings;
import gui.settings.textSettings;
import javax.swing.JOptionPane;


public class SettingsScreen extends javax.swing.JFrame implements IOrganizer {


    public SettingsScreen() {
        initComponents();
        getEdits();
    }


    @Override
    public void getEdits(){
        this.setLocationRelativeTo(null);
        settingscreenPanel.setFocusable(true);
        textSettings.setOnlyNumber(phonenumTextField);
        textSettings.setMaximumLimit(phonenumTextField, 10);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        settingscreenPanel = new javax.swing.JPanel();
        previosiconLabel = new javax.swing.JLabel();
        usernamesurnameLabel = new javax.swing.JLabel();
        messagetelno = new javax.swing.JLabel();
        phonenumTextField = new javax.swing.JTextField();
        passwordchangeicon = new javax.swing.JLabel();
        passwordlabel = new javax.swing.JLabel();
        passwordTextField = new javax.swing.JTextField();
        phonechangeicon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        settingscreenPanel.setBackground(new java.awt.Color(255, 255, 204));

        previosiconLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/imageedit_5_3525536668.png"))); // NOI18N
        previosiconLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        previosiconLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                previosiconLabelMouseClicked(evt);
            }
        });

        usernamesurnameLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        usernamesurnameLabel.setForeground(new java.awt.Color(255, 0, 51));
        usernamesurnameLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        usernamesurnameLabel.setText("[USERNAME AND SURNAME]");

        messagetelno.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        messagetelno.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        messagetelno.setText("Phone number : ");

        phonenumTextField.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        phonenumTextField.setEnabled(false);

        passwordchangeicon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/updateicon.png"))); // NOI18N
        passwordchangeicon.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        passwordchangeicon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                passwordchangeiconMouseClicked(evt);
            }
        });

        passwordlabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        passwordlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        passwordlabel.setText("Password : ");

        passwordTextField.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        passwordTextField.setText("*************");
        passwordTextField.setEnabled(false);

        phonechangeicon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/updateicon.png"))); // NOI18N
        phonechangeicon.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        phonechangeicon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                phonechangeiconMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout settingscreenPanelLayout = new javax.swing.GroupLayout(settingscreenPanel);
        settingscreenPanel.setLayout(settingscreenPanelLayout);
        settingscreenPanelLayout.setHorizontalGroup(
            settingscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(settingscreenPanelLayout.createSequentialGroup()
                .addGroup(settingscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(settingscreenPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(previosiconLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(settingscreenPanelLayout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(usernamesurnameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 535, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(settingscreenPanelLayout.createSequentialGroup()
                        .addGroup(settingscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(settingscreenPanelLayout.createSequentialGroup()
                                .addGap(60, 60, 60)
                                .addComponent(messagetelno, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(32, 32, 32))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, settingscreenPanelLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(passwordlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(45, 45, 45)))
                        .addGroup(settingscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(settingscreenPanelLayout.createSequentialGroup()
                                .addComponent(passwordTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(39, 39, 39)
                                .addComponent(passwordchangeicon))
                            .addGroup(settingscreenPanelLayout.createSequentialGroup()
                                .addComponent(phonenumTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(phonechangeicon)))))
                .addContainerGap(60, Short.MAX_VALUE))
        );
        settingscreenPanelLayout.setVerticalGroup(
            settingscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(settingscreenPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(previosiconLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(usernamesurnameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addGroup(settingscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(settingscreenPanelLayout.createSequentialGroup()
                        .addGroup(settingscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(phonenumTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(messagetelno, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(65, 65, 65)
                        .addGroup(settingscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(settingscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(passwordlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(passwordTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(passwordchangeicon, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(phonechangeicon, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(208, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(settingscreenPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(settingscreenPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void previosiconLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_previosiconLabelMouseClicked
        ActionSettings.setVisible(this, new AccountScreen());
    }//GEN-LAST:event_previosiconLabelMouseClicked

    private int clickCounter = 0;
    private void phonechangeiconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_phonechangeiconMouseClicked
        if(this.clickCounter==0){//if have never clicked
            phonenumTextField.setEnabled(true);
            iconsettings.changeIcon(phonechangeicon, "update2");
            clickCounter++;
        }
        else{
            phonenumTextField.setEnabled(false);
            JOptionPane.showMessageDialog(this, "Your phone number is updated.");
            iconsettings.setOrginalIcon(phonechangeicon);
            clickCounter=0;
        }
    }//GEN-LAST:event_phonechangeiconMouseClicked

    private void passwordchangeiconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_passwordchangeiconMouseClicked
        ActionSettings.setVisible(this, new UpdatePasswordScreen());
    }//GEN-LAST:event_passwordchangeiconMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SettingsScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SettingsScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SettingsScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SettingsScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SettingsScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel messagetelno;
    private javax.swing.JTextField passwordTextField;
    private javax.swing.JLabel passwordchangeicon;
    private javax.swing.JLabel passwordlabel;
    private javax.swing.JLabel phonechangeicon;
    private javax.swing.JTextField phonenumTextField;
    private javax.swing.JLabel previosiconLabel;
    private javax.swing.JPanel settingscreenPanel;
    private javax.swing.JLabel usernamesurnameLabel;
    // End of variables declaration//GEN-END:variables
}


package gui.settings;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;


public class iconsettings {
    
    private static Icon originalIcon;
    
    public static void changeIcon(JLabel label,String filename){
        originalIcon = label.getIcon();
        label.setIcon(new ImageIcon(Package.getPackages().getClass().getResource("gui/images/"+filename+".png")));
    }
    public static void setOrginalIcon(JLabel label){
        label.setIcon(originalIcon);
    }
}

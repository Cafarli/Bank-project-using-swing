package gui.settings;

import java.awt.Color;
import javax.swing.JButton;

public class ButtonSettings {
    
    /*
    *Background and letter color settings
    */
    
    private static Color originalBgColor, originalFgColor;
    
    public static void setBgFg(JButton button, Color bgColor,Color fgColor){
        originalBgColor=button.getBackground();
        originalFgColor=button.getForeground();
        button.setBackground(bgColor);
        button.setForeground(fgColor);
    }
    public static void setoriginalBgFg(JButton button){
        button.setBackground(originalBgColor);
        button.setForeground(originalFgColor);
    }
    /*
    
    */
}

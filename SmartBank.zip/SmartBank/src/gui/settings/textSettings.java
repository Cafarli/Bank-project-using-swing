/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui.settings;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JTextField;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;


public class textSettings {
    
    /*
    *Text focus settings
    */
    
    private static String originalText;
    private static Color originalFGcolor;
    
    public static void checkTheTextFocusGained(JTextField textField, String org){
        originalText=org;
        if(textField.getText().trim().equals(org)){
            originalFGcolor=textField.getForeground();
            textField.setText("");
        }
        textField.setForeground(Color.red);
    }
    public static void checkTheTextFocusLost(JTextField textField){
        if(textField.getText().trim().equals("")){
            textField.setForeground(originalFGcolor);
            textField.setText(originalText);
        }
        else{
            textField.setForeground(Color.black);
        }
    }
    
    /*
    *key settings 
    */
    public static void setOnlyNumber(JTextField textField){
        textField.addKeyListener(new KeyAdapter(){
            @Override
            public void keyTyped(KeyEvent e){
                char c = e.getKeyChar();
                        if(!Character.isDigit(c))
                            e.consume();
            }
        });
    }
    public static void setOnlyAlphabetic(JTextField textField){
        textField.addKeyListener(new KeyAdapter(){
            
            @Override
            public void keyTyped(KeyEvent e){
                char c = e.getKeyChar();
                        if(!Character.isAlphabetic(c))
                            e.consume();
            }
        });
    }
    /*
    Limit Ayarlari
    */
    private static int limit;
    public static void setMaximumLimit(JTextField textField, int lim){
        limit=lim;
        textField.setDocument(new PlainDocument(){
        
            @Override
            public void insertString(int offs, String str, AttributeSet a) throws BadLocationException{
                if(str==null)
                    return;
                if(getLength()+str.length()<=limit){
                super.insertString(offs,str,a);
            
                }
            }
    });
    }
    public static int checkTextKeyReleased(JTextField textField, int moneyLimit){
        String text = textField.getText();
        if(!text.equals("")){
        int amount = Integer.valueOf(text);
        if(amount > moneyLimit){
            amount=moneyLimit;
            textField.setText(String.valueOf(amount));
        }
        return amount;
        }
        return 0;
        }
}

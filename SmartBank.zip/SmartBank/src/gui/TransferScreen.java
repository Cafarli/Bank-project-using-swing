/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import gui.settings.ActionSettings;
import gui.settings.IOrganizer;
import gui.settings.textSettings;
import javax.swing.JOptionPane;


public class TransferScreen extends javax.swing.JFrame implements IOrganizer{

    private int transferamount=0;
    private final String customer_num_text_orginal="Customer No";
            
    public TransferScreen() {
        initComponents();
        getEdits();
    }

    public void getEdits(){
        this.setLocationRelativeTo(null);
        transferPanel.setFocusable(true);
        textSettings.setOnlyNumber(customernumTextField);
        textSettings.setOnlyNumber(transferamountTextField);
        textSettings.setMaximumLimit(transferamountTextField, 5);
        customernumTextField.setText(customer_num_text_orginal);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        transferPanel = new javax.swing.JPanel();
        usernamesurnameLabel = new javax.swing.JLabel();
        limitLabel = new javax.swing.JLabel();
        totalbalanceLabel = new javax.swing.JLabel();
        balanceamountLabel = new javax.swing.JLabel();
        transferamountLabel = new javax.swing.JLabel();
        transferamountTextField = new javax.swing.JTextField();
        transferButton = new javax.swing.JButton();
        previosiconLabel = new javax.swing.JLabel();
        customernumberLabel = new javax.swing.JLabel();
        customernumTextField = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        transferPanel.setBackground(new java.awt.Color(153, 255, 255));

        usernamesurnameLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        usernamesurnameLabel.setForeground(new java.awt.Color(255, 51, 51));
        usernamesurnameLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        usernamesurnameLabel.setText("[USERNAME AND SURNAME]");

        limitLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        limitLabel.setText("You can transfer 20000 AZN and less in one go.");

        totalbalanceLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        totalbalanceLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        totalbalanceLabel.setText("Total Balance  :");

        balanceamountLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        balanceamountLabel.setText("[BALANCE]");

        transferamountLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        transferamountLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        transferamountLabel.setText("Transfer amount  :");

        transferamountTextField.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        transferamountTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                transferamountTextFieldActionPerformed(evt);
            }
        });
        transferamountTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                transferamountTextFieldKeyReleased(evt);
            }
        });

        transferButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        transferButton.setText("Transfer");
        transferButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        transferButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                transferButtonActionPerformed(evt);
            }
        });

        previosiconLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/previousicontransfer.png"))); // NOI18N
        previosiconLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        previosiconLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                previosiconLabelMouseClicked(evt);
            }
        });

        customernumberLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        customernumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        customernumberLabel.setText("Customer number  :");

        customernumTextField.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        customernumTextField.setForeground(new java.awt.Color(153, 153, 153));
        customernumTextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                customernumTextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                customernumTextFieldFocusLost(evt);
            }
        });
        customernumTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customernumTextFieldActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout transferPanelLayout = new javax.swing.GroupLayout(transferPanel);
        transferPanel.setLayout(transferPanelLayout);
        transferPanelLayout.setHorizontalGroup(
            transferPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transferPanelLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(previosiconLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(transferPanelLayout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addComponent(usernamesurnameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 535, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(transferPanelLayout.createSequentialGroup()
                .addGap(128, 128, 128)
                .addComponent(limitLabel))
            .addGroup(transferPanelLayout.createSequentialGroup()
                .addGap(108, 108, 108)
                .addComponent(totalbalanceLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(balanceamountLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(transferPanelLayout.createSequentialGroup()
                .addGap(118, 118, 118)
                .addComponent(transferamountLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(transferamountTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(transferPanelLayout.createSequentialGroup()
                .addGap(118, 118, 118)
                .addComponent(customernumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(customernumTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(transferPanelLayout.createSequentialGroup()
                .addGap(260, 260, 260)
                .addComponent(transferButton))
        );
        transferPanelLayout.setVerticalGroup(
            transferPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transferPanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(previosiconLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addComponent(usernamesurnameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(limitLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addGroup(transferPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(totalbalanceLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(balanceamountLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(transferPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(transferamountLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(transferPanelLayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(transferamountTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(30, 30, 30)
                .addGroup(transferPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(customernumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(transferPanelLayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(customernumTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(transferButton, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(transferPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(transferPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void transferamountTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_transferamountTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_transferamountTextFieldActionPerformed

    private void transferamountTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_transferamountTextFieldKeyReleased
        this.transferamount = textSettings.checkTextKeyReleased(transferamountTextField, 20000);
    }//GEN-LAST:event_transferamountTextFieldKeyReleased

    private void transferButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_transferButtonActionPerformed
        JOptionPane.showMessageDialog(this, "Succesfully.\n"+
            "Amount : "+this.transferamount+" AZN.");
        ActionSettings.setVisible(this, new AccountScreen());
    }//GEN-LAST:event_transferButtonActionPerformed

    private void previosiconLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_previosiconLabelMouseClicked
        ActionSettings.setVisible(this, new AccountScreen());
    }//GEN-LAST:event_previosiconLabelMouseClicked

    private void customernumTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customernumTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_customernumTextFieldActionPerformed

    private void customernumTextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_customernumTextFieldFocusGained
        textSettings.checkTheTextFocusGained(customernumTextField, customer_num_text_orginal);
    }//GEN-LAST:event_customernumTextFieldFocusGained

    private void customernumTextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_customernumTextFieldFocusLost
        textSettings.checkTheTextFocusLost(customernumTextField);
    }//GEN-LAST:event_customernumTextFieldFocusLost

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TransferScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TransferScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TransferScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TransferScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TransferScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel balanceamountLabel;
    private javax.swing.JTextField customernumTextField;
    private javax.swing.JLabel customernumberLabel;
    private javax.swing.JLabel limitLabel;
    private javax.swing.JLabel previosiconLabel;
    private javax.swing.JLabel totalbalanceLabel;
    private javax.swing.JButton transferButton;
    private javax.swing.JPanel transferPanel;
    private javax.swing.JLabel transferamountLabel;
    private javax.swing.JTextField transferamountTextField;
    private javax.swing.JLabel usernamesurnameLabel;
    // End of variables declaration//GEN-END:variables
}

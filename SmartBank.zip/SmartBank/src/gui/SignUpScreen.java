/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import gui.settings.ActionSettings;
import gui.settings.ButtonSettings;
import gui.settings.IOrganizer;
import gui.settings.textSettings;
import java.awt.Color;
import javax.swing.JOptionPane;


public class SignUpScreen extends javax.swing.JFrame implements IOrganizer {

    
    public SignUpScreen() {
        initComponents();
        getEdits();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        signupscreenPanel = new javax.swing.JPanel();
        securityquestionlabel = new javax.swing.JLabel();
        personalinformationlabel = new javax.swing.JLabel();
        namesurnametext = new javax.swing.JTextField();
        azeno = new javax.swing.JLabel();
        azetext = new javax.swing.JTextField();
        phnum = new javax.swing.JLabel();
        phnumtext = new javax.swing.JTextField();
        Securityinformationlabel = new javax.swing.JLabel();
        namesurnamelabel1 = new javax.swing.JLabel();
        securityquestion = new javax.swing.JComboBox<>();
        answer = new javax.swing.JTextField();
        answertext = new javax.swing.JLabel();
        signupbutton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Smart bank sign up screen");

        signupscreenPanel.setBackground(new java.awt.Color(255, 255, 204));

        securityquestionlabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        securityquestionlabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        securityquestionlabel.setText("Security Question :");

        personalinformationlabel.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        personalinformationlabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        personalinformationlabel.setText("Personal Information");

        namesurnametext.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        azeno.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        azeno.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        azeno.setText("AZE No :");

        azetext.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        phnum.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        phnum.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        phnum.setText("Phone number : ");

        phnumtext.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        Securityinformationlabel.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        Securityinformationlabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Securityinformationlabel.setText("Security Information");

        namesurnamelabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        namesurnamelabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        namesurnamelabel1.setText("Name Surname :");

        securityquestion.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        securityquestion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "How old are you?", "What is your pet animal's name?", "What is your favourite films?", "Where are your favourite city?", "Enter any sentence(recommended)" }));

        answer.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        answertext.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        answertext.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        answertext.setText("Answer : ");

        signupbutton.setBackground(new java.awt.Color(153, 255, 153));
        signupbutton.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        signupbutton.setText("SignUp");
        signupbutton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        signupbutton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                signupbuttonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                signupbuttonMouseExited(evt);
            }
        });
        signupbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signupbuttonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout signupscreenPanelLayout = new javax.swing.GroupLayout(signupscreenPanel);
        signupscreenPanel.setLayout(signupscreenPanelLayout);
        signupscreenPanelLayout.setHorizontalGroup(
            signupscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(signupscreenPanelLayout.createSequentialGroup()
                .addGroup(signupscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(signupscreenPanelLayout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(personalinformationlabel))
                    .addGroup(signupscreenPanelLayout.createSequentialGroup()
                        .addGap(71, 71, 71)
                        .addComponent(Securityinformationlabel)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, signupscreenPanelLayout.createSequentialGroup()
                .addGap(0, 131, Short.MAX_VALUE)
                .addGroup(signupscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, signupscreenPanelLayout.createSequentialGroup()
                        .addGroup(signupscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(signupscreenPanelLayout.createSequentialGroup()
                                .addComponent(answertext, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(answer, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(signupscreenPanelLayout.createSequentialGroup()
                                .addGroup(signupscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, signupscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(signupscreenPanelLayout.createSequentialGroup()
                                            .addGap(10, 10, 10)
                                            .addComponent(azeno, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(phnum, javax.swing.GroupLayout.Alignment.TRAILING))
                                    .addComponent(namesurnamelabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(securityquestionlabel, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(signupscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(azetext, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(namesurnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(phnumtext, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(securityquestion, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(80, 80, 80))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, signupscreenPanelLayout.createSequentialGroup()
                        .addComponent(signupbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(205, 205, 205))))
        );
        signupscreenPanelLayout.setVerticalGroup(
            signupscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(signupscreenPanelLayout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addComponent(personalinformationlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(signupscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(signupscreenPanelLayout.createSequentialGroup()
                        .addComponent(namesurnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, signupscreenPanelLayout.createSequentialGroup()
                        .addComponent(namesurnamelabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)))
                .addGroup(signupscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(azeno, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(azetext, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(signupscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(phnum, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(phnumtext, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(42, 42, 42)
                .addComponent(Securityinformationlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(signupscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(securityquestionlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(securityquestion, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(signupscreenPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(answer, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(answertext, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addComponent(signupbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(81, 81, 81))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(signupscreenPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(signupscreenPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void signupbuttonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signupbuttonMouseEntered
        ButtonSettings.setBgFg(signupbutton, Color.black, Color.white);
    }//GEN-LAST:event_signupbuttonMouseEntered

    private void signupbuttonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signupbuttonMouseExited
        ButtonSettings.setoriginalBgFg(signupbutton);
    }//GEN-LAST:event_signupbuttonMouseExited

    private void signupbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signupbuttonActionPerformed
        JOptionPane.showMessageDialog(this, "You signed up successfully.");
        ActionSettings.setVisible(this,new LoginScreen());
    }//GEN-LAST:event_signupbuttonActionPerformed

    @Override
    public void getEdits(){
        this.setLocationRelativeTo(null);
        signupscreenPanel.setFocusable(true);
        textSettings.setOnlyAlphabetic(namesurnametext);
        textSettings.setOnlyNumber(phnumtext);
        textSettings.setOnlyNumber(azetext);
        textSettings.setMaximumLimit(azetext, 9);
        textSettings.setMaximumLimit(phnumtext, 10);
        
    }
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SignUpScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SignUpScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SignUpScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SignUpScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SignUpScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Securityinformationlabel;
    private javax.swing.JTextField answer;
    private javax.swing.JLabel answertext;
    private javax.swing.JLabel azeno;
    private javax.swing.JTextField azetext;
    private javax.swing.JLabel namesurnamelabel1;
    private javax.swing.JTextField namesurnametext;
    private javax.swing.JLabel personalinformationlabel;
    private javax.swing.JLabel phnum;
    private javax.swing.JTextField phnumtext;
    private javax.swing.JComboBox<String> securityquestion;
    private javax.swing.JLabel securityquestionlabel;
    private javax.swing.JButton signupbutton;
    private javax.swing.JPanel signupscreenPanel;
    // End of variables declaration//GEN-END:variables
}

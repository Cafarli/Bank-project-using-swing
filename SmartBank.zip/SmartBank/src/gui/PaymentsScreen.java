/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import gui.settings.ActionSettings;
import gui.settings.ButtonSettings;
import gui.settings.IOrganizer;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JButton;
import javax.swing.JOptionPane;


public class PaymentsScreen extends javax.swing.JFrame implements IOrganizer {


    public PaymentsScreen() {
        initComponents();
        getEdits();
    }

    @Override
    public void getEdits(){
        this.setLocationRelativeTo(null);
        paymentsPanel.setFocusable(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        paymentsPanel = new javax.swing.JPanel();
        previosiconLabel = new javax.swing.JLabel();
        usernamesurnameLabel = new javax.swing.JLabel();
        messageelectLabel = new javax.swing.JLabel();
        electdebt = new javax.swing.JLabel();
        electpayButton = new javax.swing.JButton();
        messagewaterLabel = new javax.swing.JLabel();
        waterdebt = new javax.swing.JLabel();
        waterpayButton = new javax.swing.JButton();
        messagegasLabel = new javax.swing.JLabel();
        gasdebt = new javax.swing.JLabel();
        gaspayButton = new javax.swing.JButton();
        interpayButton = new javax.swing.JButton();
        interdebt = new javax.swing.JLabel();
        messageintLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                formMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                formMouseExited(evt);
            }
        });

        paymentsPanel.setBackground(new java.awt.Color(204, 223, 255));
        paymentsPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                formMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                formMouseExited(evt);
            }
        });

        previosiconLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/previousiconpayments.png"))); // NOI18N
        previosiconLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        previosiconLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                previosiconLabelMouseClicked(evt);
            }
        });

        usernamesurnameLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        usernamesurnameLabel.setForeground(new java.awt.Color(255, 0, 51));
        usernamesurnameLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        usernamesurnameLabel.setText("[USERNAME AND SURNAME]");

        messageelectLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        messageelectLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        messageelectLabel.setText("Total electricity debt:  ");

        electdebt.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        electdebt.setForeground(new java.awt.Color(0, 0, 255));
        electdebt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        electdebt.setText("[ELECT DEBT]");

        electpayButton.setBackground(new java.awt.Color(255, 255, 204));
        electpayButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        electpayButton.setText("Pay");
        electpayButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        electpayButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                electpayButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                electpayButtonMouseExited(evt);
            }
        });
        electpayButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                electpayButtonActionPerformed(evt);
            }
        });

        messagewaterLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        messagewaterLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        messagewaterLabel.setText("Total water debt:  ");

        waterdebt.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        waterdebt.setForeground(new java.awt.Color(0, 0, 255));
        waterdebt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        waterdebt.setText("[WATER DEBT]");

        waterpayButton.setBackground(new java.awt.Color(204, 255, 204));
        waterpayButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        waterpayButton.setText("Pay");
        waterpayButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        waterpayButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                formMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                formMouseExited(evt);
            }
        });
        waterpayButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                waterpayButtonActionPerformed(evt);
            }
        });

        messagegasLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        messagegasLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        messagegasLabel.setText("Total gas debt:  ");

        gasdebt.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        gasdebt.setForeground(new java.awt.Color(0, 0, 255));
        gasdebt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        gasdebt.setText("[GAS DEBT]");

        gaspayButton.setBackground(new java.awt.Color(255, 102, 102));
        gaspayButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        gaspayButton.setText("Pay");
        gaspayButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        gaspayButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                formMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                formMouseExited(evt);
            }
        });
        gaspayButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gaspayButtonActionPerformed(evt);
            }
        });

        interpayButton.setBackground(new java.awt.Color(0, 255, 255));
        interpayButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        interpayButton.setText("Pay");
        interpayButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        interpayButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                formMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                formMouseExited(evt);
            }
        });
        interpayButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                interpayButtonActionPerformed(evt);
            }
        });

        interdebt.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        interdebt.setForeground(new java.awt.Color(0, 0, 255));
        interdebt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        interdebt.setText("[INTER DEBT]");

        messageintLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        messageintLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        messageintLabel.setText("Total internet debt:  ");

        javax.swing.GroupLayout paymentsPanelLayout = new javax.swing.GroupLayout(paymentsPanel);
        paymentsPanel.setLayout(paymentsPanelLayout);
        paymentsPanelLayout.setHorizontalGroup(
            paymentsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paymentsPanelLayout.createSequentialGroup()
                .addGroup(paymentsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(paymentsPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(previosiconLabel))
                    .addGroup(paymentsPanelLayout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addComponent(messageelectLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)
                        .addComponent(electdebt, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(60, 60, 60)
                        .addComponent(electpayButton))
                    .addGroup(paymentsPanelLayout.createSequentialGroup()
                        .addGap(71, 71, 71)
                        .addGroup(paymentsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(paymentsPanelLayout.createSequentialGroup()
                                .addGap(25, 25, 25)
                                .addComponent(messagegasLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(59, 59, 59)
                                .addComponent(gasdebt, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(60, 60, 60)
                                .addComponent(gaspayButton))
                            .addComponent(usernamesurnameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 535, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(paymentsPanelLayout.createSequentialGroup()
                                .addGroup(paymentsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(paymentsPanelLayout.createSequentialGroup()
                                        .addGap(34, 34, 34)
                                        .addComponent(messagewaterLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(50, 50, 50))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, paymentsPanelLayout.createSequentialGroup()
                                        .addComponent(messageintLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(59, 59, 59)))
                                .addGroup(paymentsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(paymentsPanelLayout.createSequentialGroup()
                                        .addComponent(interdebt, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(60, 60, 60)
                                        .addComponent(interpayButton))
                                    .addGroup(paymentsPanelLayout.createSequentialGroup()
                                        .addComponent(waterdebt, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(60, 60, 60)
                                        .addComponent(waterpayButton)))))))
                .addContainerGap(103, Short.MAX_VALUE))
        );

        paymentsPanelLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {electdebt, gasdebt, interdebt, waterdebt});

        paymentsPanelLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {electpayButton, gaspayButton, interpayButton, waterpayButton});

        paymentsPanelLayout.setVerticalGroup(
            paymentsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paymentsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(previosiconLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(usernamesurnameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addGroup(paymentsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(messageelectLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(electdebt, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(electpayButton))
                .addGap(49, 49, 49)
                .addGroup(paymentsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(messagewaterLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(waterdebt, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(waterpayButton))
                .addGap(49, 49, 49)
                .addGroup(paymentsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(messagegasLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(gasdebt, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(gaspayButton))
                .addGap(49, 49, 49)
                .addGroup(paymentsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(messageintLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(interdebt, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(interpayButton))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        paymentsPanelLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {electdebt, gasdebt, interdebt, waterdebt});

        paymentsPanelLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {electpayButton, gaspayButton, interpayButton, waterpayButton});

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(paymentsPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(paymentsPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void previosiconLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_previosiconLabelMouseClicked
        ActionSettings.setVisible(this, new AccountScreen());
    }//GEN-LAST:event_previosiconLabelMouseClicked

    /*
    *button color
    */
    private void setBgFg(Component c){
        ButtonSettings.setBgFg((JButton)c, Color.GREEN, Color.YELLOW);
    }
    private void formMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseEntered
        this.setBgFg(evt.getComponent());
    }//GEN-LAST:event_formMouseEntered

    private void formMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseExited
        ButtonSettings.setoriginalBgFg((JButton)evt.getComponent());
    }//GEN-LAST:event_formMouseExited

    private void electpayButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_electpayButtonMouseEntered
        this.setBgFg(evt.getComponent());
    }//GEN-LAST:event_electpayButtonMouseEntered

    private void electpayButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_electpayButtonMouseExited
        ButtonSettings.setoriginalBgFg((JButton)evt.getComponent());
    }//GEN-LAST:event_electpayButtonMouseExited

    /*
    *actions
    */
    private void electpayButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_electpayButtonActionPerformed
        JOptionPane.showMessageDialog(this, "The electricity bill was paid succesfully.");
        ActionSettings.setVisible(this, new AccountScreen());
    }//GEN-LAST:event_electpayButtonActionPerformed

    private void waterpayButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_waterpayButtonActionPerformed
        JOptionPane.showMessageDialog(this, "The water bill was paid succesfully.");
        ActionSettings.setVisible(this, new AccountScreen());
    }//GEN-LAST:event_waterpayButtonActionPerformed

    private void gaspayButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gaspayButtonActionPerformed
        JOptionPane.showMessageDialog(this, "The gas bill was paid succesfully.");
        ActionSettings.setVisible(this, new AccountScreen());
    }//GEN-LAST:event_gaspayButtonActionPerformed

    private void interpayButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_interpayButtonActionPerformed
        JOptionPane.showMessageDialog(this, "The internet bill was paid succesfully.");
        ActionSettings.setVisible(this, new AccountScreen());
    }//GEN-LAST:event_interpayButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PaymentsScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PaymentsScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PaymentsScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PaymentsScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PaymentsScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel electdebt;
    private javax.swing.JButton electpayButton;
    private javax.swing.JLabel gasdebt;
    private javax.swing.JButton gaspayButton;
    private javax.swing.JLabel interdebt;
    private javax.swing.JButton interpayButton;
    private javax.swing.JLabel messageelectLabel;
    private javax.swing.JLabel messagegasLabel;
    private javax.swing.JLabel messageintLabel;
    private javax.swing.JLabel messagewaterLabel;
    private javax.swing.JPanel paymentsPanel;
    private javax.swing.JLabel previosiconLabel;
    private javax.swing.JLabel usernamesurnameLabel;
    private javax.swing.JLabel waterdebt;
    private javax.swing.JButton waterpayButton;
    // End of variables declaration//GEN-END:variables
}
